fpl_reader
==========

A Python library that lets you read Foobar2000's `.fpl` playlist files.

Usage:

1. Test the library with `pytest`
2. Install the library with `pip install --user .`
3. Run the playlist reader with `fpl_reader path/to/playlist.fpl`

If you don't like to install stuff, you can also use `python3 -m fpl_reader
playlist.fpl` directly from inside the project root directory.

Documentation
=============

See [fpl-format.md](fpl-format.md) for FPL file format documentation.
