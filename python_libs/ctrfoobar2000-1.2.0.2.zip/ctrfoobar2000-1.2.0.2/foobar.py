from ctrfoobar2000 import foobar

if __name__ == "__main__":
	foobar.main()